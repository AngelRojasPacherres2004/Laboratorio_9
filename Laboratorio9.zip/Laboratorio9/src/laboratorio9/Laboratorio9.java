/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package laboratorio9;

import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author ferna
 */
public class Laboratorio9 {

    /**
     * @param args the command line arguments
     */
   public static void main(String[] args) throws InterruptedException {
        Scanner sc = new Scanner(System.in);
        int ancho = 30;
        int altura = 30;
        
        
        int tanque1X = 13;
        int tanque1Y = 28;
        int tanque2X = 12;
        int tanque2Y = 29;
        int tanque3X = 13;
        int tanque3Y = 29;
        int tanque4X = 14;
        int tanque4Y = 25;
        
        int tanqueBalaX=13;
        int tanqueBalaY=25;
        
        char caracter = '0';
        char caracterTanque = '-';
        char caracterTanqueBala= '|';
        
         while(true){
             limpiarPantalla();
             if(tanqueBalaY >=0)tanqueBalaY--;
         for(int i=0; i<altura; i++){
            for(int j=0; j<ancho; j++){
             System.out.print(caracter);
                if(i==tanque1X && j==tanque1Y)System.out.print(caracter+"");
                else if(j==tanque2X && i==tanque2Y)System.out.print(caracter+" ");
                else if(j==tanque3X && i==tanque3Y)System.out.print(caracter+" ");
                else if(j==tanque4X && i==tanque4Y)System.out.print(caracter+" ");
                else System.out.print(caracter+" ");
                }
                 System.out.print("\n");
            }
            esperar();
            String letra = sc.next();
            JOptionPane.showMessageDialog(null, letra);
            if(letra.equalsIgnoreCase("w")){
            tanque1Y--;tanque2Y--;tanque3Y--;tanque4Y--;
            }else if(letra.equalsIgnoreCase("s")){
            tanque1Y++;tanque2Y++;tanque3Y++;tanque4Y++;
            }else if(letra.equalsIgnoreCase("d")){
            tanque1X++;tanque2X++;tanque3X++;tanque4X++;
            }else if(letra.equalsIgnoreCase("a")){
            tanque1X--;tanque2X--;tanque3X--;tanque4X--;
            }
         }
        }
    public static void esperar(){
      try{
        Thread.sleep(1000); 
      }catch(Exception s){}
    
    }
    
      public static void limpiarPantalla(){
       try {
             if(System.getProperty("os.name").contains("Windows"))
                  new ProcessBuilder("cmd","/c","cls").inheritIO().start().waitFor();
             else
                    Runtime.getRuntime().exec("clear");
             
         }catch(Exception  ex){}
           System.out.flush();
             
      }
    
}
